package pluralsight.airportmanagement.domain;

public enum FlightType {
    Internal,
    International
}
